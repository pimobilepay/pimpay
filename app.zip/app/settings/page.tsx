"use client";

import { useState, useEffect, useCallback } from "react";
import {
  User, ShieldCheck, Bell,
  Lock, Globe, HelpCircle, LogOut,
  ChevronRight, CreditCard, Palette,
  Loader2, ArrowLeft, Moon, Sun, History, ShieldAlert,
  Facebook, Twitter, Linkedin, MessageSquare
} from "lucide-react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { BottomNav } from "@/components/bottom-nav";

interface SettingItem {
  icon: React.ReactNode;
  label: string;
  desc: string;
  color: string;
  path?: string;
  badge?: string;
  onClick?: () => void;
}

interface SettingSection {
  title: string;
  items: SettingItem[];
}

export default function SettingsPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);

  // Chargement immédiat des données locales pour éviter l'écran blanc
  useEffect(() => {
    const savedTheme = localStorage.getItem("pimpay-theme");
    const isDark = savedTheme !== "light";
    setIsDarkMode(isDark);
    
    // Chargement immédiat du cache utilisateur
    const localUser = localStorage.getItem("pimpay_user");
    if (localUser) {
      try {
        setUser(JSON.parse(localUser));
      } catch (e) {
        console.error("Erreur parsing user:", e);
      }
    }
  }, []);

  const fetchUserData = useCallback(async () => {
    if (isLoading) return; // Éviter les appels multiples
    setIsLoading(true);
    
    try {
      const response = await fetch("/api/user/profile", {
        cache: 'no-store',
        headers: { 'Content-Type': 'application/json' }
      });

      if (response.ok) {
        const result = await response.json();
        const userData = result.user || result;
        setUser(userData);
        localStorage.setItem("pimpay_user", JSON.stringify(userData));
      } else if (response.status === 401) {
        router.push("/auth/login");
      }
    } catch (err) {
      console.error("Erreur de synchronisation Pimpay:", err);
    } finally {
      setIsLoading(false);
    }
  }, [router, isLoading]);

  useEffect(() => {
    // Synchronisation en arrière-plan uniquement
    fetchUserData();
  }, []);

  const userName = user?.name || user?.firstName || "Pioneer";
  const userEmail = user?.email || "Chargement...";
  const userKyc = user?.kycStatus || 'NON VÉRIFIÉ';
  const userRole = user?.role || 'PIONEER';
  const userId = user?.id?.substring(0, 8).toUpperCase() || "ID-WAIT";

  const handleLogout = async () => {
    try {
      const loadingToast = toast.loading("Fermeture de la session sécurisée...");
      
      // Call logout API to properly terminate the session on the backend
      const response = await fetch("/api/auth/logout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });

      // Clean up client-side data regardless of API response
      document.cookie = "token=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT";
      document.cookie = "pi_session_token=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT";
      localStorage.removeItem("pimpay_user");
      localStorage.clear(); // Clear all localStorage data
      
      toast.dismiss(loadingToast);
      
      if (response.ok) {
        toast.success("Déconnecté avec succès");
      } else {
        toast.success("Session fermée localement");
      }
      
      // Redirect to login
      router.push("/auth/login");
      router.refresh();
    } catch (error) {
      console.error("[v0] Logout error:", error);
      // Still log out locally even if backend fails
      document.cookie = "token=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT";
      document.cookie = "pi_session_token=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT";
      localStorage.clear();
      toast.success("Session fermée");
      router.push("/auth/login");
    }
  };

  const toggleTheme = () => {
    const newMode = !isDarkMode;
    setIsDarkMode(newMode);
    if (newMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("pimpay-theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("pimpay-theme", "light");
    }
    toast.success(`Mode ${newMode ? 'Sombre' : 'Clair'} activé`);
  };

  const menuItems: SettingSection[] = [
    {
      title: "Compte & Sécurité",
      items: [
        { icon: <User size={18} />, label: "Profil Utilisateur", desc: userEmail, color: "text-blue-400", path: "/profile" },
        {
          icon: <ShieldCheck size={18} />,
          label: "Vérification KYC",
          desc: `Statut: ${userKyc}`,
          badge: userKyc === 'VERIFIED' ? "OK" : "REQUIS",
          color: userKyc === 'VERIFIED' ? "text-emerald-400" : "text-amber-400",
          path: "/settings/kyc"
        },
        {
          icon: <ShieldAlert size={18} />,
          label: "Sécurité",
          desc: "Mot de passe & Protection",
          color: "text-purple-400",
          path: "/settings/security",
        },
        {
          icon: <History size={18} />,
          label: "Historique de Connexion",
          desc: "Vérifier les activités récentes",
          color: "text-rose-400",
          path: "/settings/sessions"
        },
      ]
    },
    {
      title: "Préférences Système",
      items: [
        {
          icon: isDarkMode ? <Moon size={18} /> : <Sun size={18} />,
          label: "Apparence",
          desc: isDarkMode ? "Mode Sombre activé" : "Mode Clair activé",
          color: "text-yellow-400",
          onClick: toggleTheme
        },
        { icon: <Palette size={18} />, label: "Thème Personnalisé", desc: "Couleurs d'accentuation", color: "text-indigo-400", path: "/settings/theme" },
        { icon: <Globe size={18} />, label: "Langue & Région", desc: "Français (FR) • USD", color: "text-cyan-400", path: "/settings/language" },
      ]
    },
    {
      title: "Services Pimpay",
      items: [
        { icon: <CreditCard size={18} />, label: "Mes Cartes PIMPAY", desc: "Gérer vos cartes virtuelles", color: "text-pink-400", path: "/cards" },
        { icon: <Bell size={18} />, label: "Notifications", desc: "Alertes de transaction", color: "text-orange-400", path: "/settings/notifications" },
      ]
    },
    {
      title: "Légal & Support",
      items: [
        { icon: <MessageSquare size={18} />, label: "Contact", desc: "Discuter avec le support", color: "text-emerald-400", path: "/contacts" },
        { icon: <HelpCircle size={18} />, label: "Centre d'aide", desc: "Support technique 24/7", color: "text-slate-400", path: "/support" },
        { icon: <Lock size={18} />, label: "Confidentialité", desc: "RGPD & Sécurité des données", color: "text-slate-400", path: "/legal/privacy" },
        { icon: <ShieldCheck size={18} />, label: "Conditions d'utilisation", desc: "Contrat d'utilisateur final", color: "text-slate-400", path: "/legal/terms" },
      ]
    }
  ];

  // Affichage immédiat avec les données en cache
  return (
    <div className={`min-h-screen ${isDarkMode ? 'bg-[#020617]' : 'bg-slate-50'} ${isDarkMode ? 'text-white' : 'text-slate-900'} pb-32 font-sans overflow-x-hidden transition-colors duration-500`}>
      <div className="px-6 pt-8 flex items-center gap-4">
        <button onClick={() => router.back()} className={`p-3 ${isDarkMode ? 'bg-white/5 border-white/10 text-white' : 'bg-white border-slate-200 shadow-sm text-slate-900'} rounded-2xl border active:scale-90 transition-transform`}>
          <ArrowLeft size={20} />
        </button>
        <h1 className={`text-xl font-black uppercase tracking-tighter`}>Paramètres</h1>
      </div>

      <header className="p-8 pb-4 text-center">
        <div className="relative inline-block group">
          <div className="w-24 h-24 bg-gradient-to-tr from-blue-600 to-indigo-500 rounded-full mx-auto flex items-center justify-center text-3xl font-black shadow-2xl shadow-blue-500/20 border-4 border-current uppercase group-hover:scale-105 transition-transform duration-300 overflow-hidden">
            {user?.avatar ? (
                <img src={user.avatar} alt="Avatar" className="w-full h-full object-cover" />
            ) : (
                userName.charAt(0)
            )}
          </div>
          {userKyc === 'VERIFIED' && (
            <div className="absolute bottom-0 right-0 bg-emerald-500 p-1.5 rounded-full border-4 border-[#020617] shadow-lg">
               <ShieldCheck size={14} className="text-white" />
            </div>
          )}
        </div>
        <h2 className="mt-4 text-xl font-black uppercase tracking-tighter">{userName}</h2>
        <p className="text-[10px] font-bold text-blue-500 tracking-widest uppercase mt-1">
          {userRole} MEMBER • ID: {userId}
        </p>
      </header>

      <main className="px-6 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
        {menuItems.map((section, idx) => (
          <div key={idx} className="space-y-3">
            <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-2">
              {section.title}
            </h3>
            <div className={`${isDarkMode ? 'bg-slate-900/40 border-white/5' : 'bg-white border-slate-200 shadow-sm'} border rounded-[32px] overflow-hidden backdrop-blur-sm`}>
              {section.items.map((item, i) => (
                <button
                  key={i}
                  onClick={() => {
                    if (item.onClick) {
                      item.onClick();
                    } else if (item.path) {
                      router.push(item.path);
                    }
                  }}
                  className={`w-full flex items-center justify-between p-5 hover:bg-white/5 active:bg-white/10 transition-all border-b ${isDarkMode ? 'border-white/5' : 'border-slate-100'} last:border-0 group`}
                >
                  <div className="flex items-center gap-4">
                    <div className={`${item.color} ${isDarkMode ? 'bg-white/5' : 'bg-slate-100'} p-3 rounded-2xl group-hover:scale-110 transition-transform`}>
                      {item.icon}
                    </div>
                    <div className="text-left">
                      <p className={`text-xs font-black uppercase tracking-tight`}>{item.label}</p>
                      <p className="text-[10px] text-slate-500 font-bold uppercase mt-0.5">{item.desc}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {item.badge && (
                      <span className={`text-[8px] font-black px-2 py-0.5 rounded-md ${item.badge === 'OK' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'}`}>
                        {item.badge}
                      </span>
                    )}
                    <ChevronRight size={16} className="text-slate-700 group-hover:text-blue-500 transition-colors" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        ))}

        <div className="space-y-3">
            <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-2">Suivez-nous</h3>
            <div className="flex items-center justify-center gap-4 p-6">
                <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className={`p-4 rounded-2xl ${isDarkMode ? 'bg-slate-900/40' : 'bg-white shadow-sm'} text-slate-400 hover:text-blue-500 transition-colors shadow-lg active:scale-90`}>
                    <Facebook size={24} />
                </a>
                <a href="https://x.com/pimobilepay" target="_blank" rel="noopener noreferrer" className={`p-4 rounded-2xl ${isDarkMode ? 'bg-slate-900/40' : 'bg-white shadow-sm'} text-slate-400 hover:text-white transition-colors shadow-lg active:scale-90`}>
                    <Twitter size={24} />
                </a>
<a href="https://cg.linkedin.com/in/aimardswana" target="_blank" rel="noopener noreferrer" className={`p-4 rounded-2xl ${isDarkMode ? 'bg-slate-900/40' : 'bg-white shadow-sm'} text-slate-400 hover:text-blue-500 transition-colors shadow-lg active:scale-90`}>
  <Linkedin size={24} />
  </a>
                <a href="https://tiktok.com/@pimobilepay" target="_blank" rel="noopener noreferrer" className={`p-4 rounded-2xl ${isDarkMode ? 'bg-slate-900/40' : 'bg-white shadow-sm'} text-slate-400 hover:text-pink-500 transition-colors shadow-lg active:scale-90`}>
                    <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
                    </svg>
                </a>
            </div>
        </div>

        <button
          onClick={handleLogout}
          className="w-full flex items-center justify-center gap-3 p-6 bg-rose-500/5 border border-rose-500/20 rounded-[32px] text-rose-500 font-black uppercase text-xs tracking-[0.2em] hover:bg-rose-500 hover:text-white transition-all duration-300 shadow-lg active:scale-95"
        >
          <LogOut size={18} />
          Fermer la session sécurisée
        </button>

        <div className="text-center space-y-1 pb-10">
          <p className="text-[9px] text-slate-600 font-black uppercase tracking-widest">
            PIMPAY PROTOCOL v2.4.0-STABLE
          </p>
          <p className="text-[8px] text-slate-800 font-bold uppercase tracking-tighter">
            Distributed Ledger Technology • GCV Verified
          </p>
        </div>
      </main>

      <BottomNav onOpenMenu={() => {}} />
    </div>
  );
}
