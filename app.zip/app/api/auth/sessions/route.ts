export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyJWT } from "@/lib/auth";
import { cookies } from "next/headers";
import { UAParser } from "ua-parser-js";

export async function GET() {
  try {
    const cookieStore = await cookies();
    const piToken = cookieStore.get("pi_session_token")?.value;
    const token = cookieStore.get("token")?.value || cookieStore.get("pimpay_token")?.value;

    let userId: string | null = null;

    // Pi Network session
    if (piToken && piToken.length > 20) {
      userId = piToken;
    } 
    // Token JWT classique via verifyJWT
    else if (token) {
      const payload = await verifyJWT(token);
      if (!payload) {
        return NextResponse.json({ error: "Session expiree" }, { status: 401 });
      }
      userId = payload.id;
    }

    if (!userId) {
      return NextResponse.json({ error: "Non autorise" }, { status: 401 });
    }

    const sessions = await prisma.session.findMany({
      where: { userId, isActive: true },
      orderBy: { lastActiveAt: "desc" },
    });

    const enriched = sessions.map((s) => {
      const parser = new UAParser(s.userAgent || "");
      const device = parser.getDevice();
      const os = parser.getOS();
      const browser = parser.getBrowser();
      const engine = parser.getEngine();
      const cpu = parser.getCPU();

      // Build a smart display name
      const deviceDisplayName =
        // First: use device model from UA parser (e.g. "Samsung Galaxy A12")
        device.vendor && device.model
          ? `${device.vendor} ${device.model}`.trim()
        // Second: use stored name if it's not a generic value
        : s.deviceName && s.deviceName !== "Desktop" && s.deviceName !== "iPhone" && s.deviceName !== "Android"
          ? s.deviceName
        // Third: use model alone if available
        : device.model
          ? device.model
        // Fourth: build from browser + OS
        : os.name
          ? `${browser.name || "Navigateur"} sur ${os.name}`
        : s.deviceName || "Appareil Inconnu";

      const isMobile =
        device.type === "mobile" ||
        s.deviceName?.toLowerCase().includes("android") ||
        s.deviceName?.toLowerCase().includes("iphone") ||
        s.userAgent?.toLowerCase().includes("mobile");

      // Device details for system info display
      const osName = s.os || os.name || "Unknown";
      const osVersion = os.version || "";
      const browserName = s.browser || browser.name || "Navigateur";
      const browserVersion = browser.version || "";
      const deviceVendor = device.vendor || null;
      const deviceModel = device.model || null;
      const deviceType = device.type || (isMobile ? "mobile" : "desktop");
      const engineName = engine.name || null;
      const cpuArch = cpu.architecture || null;

      return {
        id: s.id,
        deviceName: deviceDisplayName,
        os: `${osName} ${osVersion}`.trim(),
        osName,
        osVersion,
        browser: browserName,
        browserVersion,
        deviceVendor,
        deviceModel,
        deviceType,
        engineName,
        cpuArch,
        ip: s.ip || "127.0.0.1",
        city: s.city || null,
        country: s.country || null,
        isMobile: !!isMobile,
        lastActiveAt: s.lastActiveAt.toISOString(),
        isCurrent: s.token === token,
      };
    });

    return NextResponse.json({ sessions: enriched });
  } catch (e) {
    console.error("SESSIONS_API_ERROR:", e);
    return NextResponse.json(
      { error: "Session expiree ou invalide" },
      { status: 401 }
    );
  }
}
