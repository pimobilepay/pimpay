export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { signSessionToken } from "@/lib/jwt";
import { cookies } from "next/headers";
import bcrypt from "bcryptjs";
import { UAParser } from "ua-parser-js";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { pin, userId: bodyUserId } = body;

    const cookieStore = await cookies();
    let userId = bodyUserId;

    if (!userId || !pin) {
      return NextResponse.json({ error: "Donnees manquantes" }, { status: 400 });
    }

    // Support both 4-digit (legacy) and 6-digit (new) PINs
    if (typeof pin !== "string" || (pin.length !== 4 && pin.length !== 6) || !/^\d+$/.test(pin)) {
      return NextResponse.json(
        { error: "Code PIN invalide. Veuillez entrer 4 ou 6 chiffres." },
        { status: 400 }
      );
    }

    // 1. RECHERCHE USER
    const user = await prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user || !user.pin) {
      return NextResponse.json({ error: "Utilisateur ou PIN non configuré" }, { status: 401 });
    }

    // 2. VÉRIFICATION DU PIN
    const isPinValid = await bcrypt.compare(pin, user.pin);
    if (!isPinValid) {
      return NextResponse.json({ error: "Code PIN incorrect" }, { status: 401 });
    }

    // 3. GÉNÉRATION DU TOKEN FINAL
    const newToken = await signSessionToken({
      id: user.id,
      role: user.role,
      email: user.email,
      username: user.username
    }, "24h");

    // --- DEBUT DES CORRECTIONS SESSIONS & LOGS ---
    const userAgent = req.headers.get("user-agent") || "Appareil Inconnu";
    const ip = req.headers.get("x-forwarded-for")?.split(',')[0] || "127.0.0.1";
    const country = req.headers.get("x-vercel-ip-country") || "CG";
    const city = req.headers.get("x-vercel-ip-city") || "Oyo";

    // Parse user agent for better device identification
    const uaParser = new UAParser(userAgent);
    const uaDevice = uaParser.getDevice();
    const uaOS = uaParser.getOS();
    const uaBrowser = uaParser.getBrowser();
    const os = uaDevice.vendor && uaDevice.model
      ? `${uaDevice.vendor} ${uaDevice.model}`
      : uaOS.name
        ? `${uaOS.name}${uaOS.version ? ` ${uaOS.version}` : ""}`
        : userAgent.includes("Android") ? "Android" : userAgent.includes("iPhone") ? "iPhone" : "Desktop";
    const browser = uaBrowser.name || (userAgent.includes("Chrome") ? "Chrome" : userAgent.includes("Safari") ? "Safari" : "Navigateur");

    try {
      // MISE À JOUR DE L'UTILISATEUR
      await prisma.user.update({
        where: { id: user.id },
        data: {
          lastLoginAt: new Date(),
          lastLoginIp: ip,
        }
      });

      // CRÉATION DE LA SESSION (Pour que SessionsPage fonctionne)
      await prisma.session.create({
        data: {
          userId: user.id,
          token: newToken, // On stocke le token final
          isActive: true,
          userAgent,
          ip,
          deviceName: os,
          os: os,
          browser: browser,
          city: city,
          country: country
        }
      });

      // NOTIFICATION DE CONNEXION RÉUSSIE
      await prisma.notification.create({
        data: {
          userId: user.id,
          type: "LOGIN",
          title: "Connexion sécurisée",
          message: `Nouvelle session établie depuis ${city}, ${country}`,
          metadata: { ip, device: os, location: `${city}, ${country}` }
        }
      });
    } catch (dbError) {
      console.error("LOGGING_ERROR:", dbError);
      // On ne bloque pas la connexion si les logs échouent
    }
    // --- FIN DES CORRECTIONS ---

    // Determiner la destination selon le role
    const getRedirectPath = (role: string) => {
      switch (role) {
        case "ADMIN": return "/admin";
        case "BANK_ADMIN": return "/bank";
        case "BUSINESS_ADMIN": return "/business";
        case "AGENT": return "/hub";
        default: return "/dashboard";
      }
    };

    const response = NextResponse.json({
      success: true,
      message: "PIN validé",
      user: { id: user.id, role: user.role },
      redirectTo: getRedirectPath(user.role)
    });

    const isProduction = process.env.NODE_ENV === "production";
    const cookieOptions = {
      httpOnly: true,
      secure: isProduction,
      sameSite: isProduction ? ("none" as const) : ("lax" as const),
      path: "/",
      maxAge: 60 * 60 * 24,
    };

    response.cookies.set("token", newToken, cookieOptions);
    response.cookies.set("pimpay_token", newToken, cookieOptions);

    return response;

  } catch (error) {
    console.error("VERIFY_ERROR:", error);
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}
