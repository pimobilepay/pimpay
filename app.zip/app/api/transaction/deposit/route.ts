export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyJWT } from "@/lib/auth";
import { cookies } from "next/headers";
import crypto from "crypto";
import { grantReferrerBonusIfEligible } from "@/app/api/referral/route";

export async function POST(req: NextRequest) {
  try {
    // 1. Authentification via JWT (lib/auth)
    const cookieStore = await cookies();
    const token = cookieStore.get("token")?.value;
    if (!token) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });

    const payload = await verifyJWT(token);
    if (!payload) return NextResponse.json({ error: "Token invalide" }, { status: 401 });
    const userId = payload.id;

    // 2. Récupération des données
    const body = await req.json();
    const { txHash, paymentId, provider, amount } = body;

    // Référence externe (Hash blockchain ou ID de paiement Pi)
    const externalRef = txHash || paymentId;
    if (!externalRef) {
      return NextResponse.json({ error: "Référence de transaction manquante" }, { status: 400 });
    }

    // 3. Anti-doublon strict
    const existingTx = await prisma.transaction.findFirst({
      where: {
        OR: [
          { blockchainTx: externalRef },
          { reference: externalRef }
        ]
      }
    });

    if (existingTx) {
      return NextResponse.json({ error: "Cette transaction a déjà été traitée" }, { status: 400 });
    }

    // 4. Identification du Wallet (Exception Pi Browser vs Normal)
    const currency = provider === "PI" ? "PI" : "USDT";
    const userWallet = await prisma.wallet.findFirst({
      where: { userId, currency }
    });

    if (!userWallet) {
      return NextResponse.json({ error: `Portefeuille ${currency} introuvable` }, { status: 404 });
    }

    // 5. Création de la transaction dans PimPay
    // Toutes les transactions entrantes sont approuvées automatiquement
    const finalAmount = parseFloat(amount) || 0;

    const deposit = await prisma.transaction.create({
      data: {
        reference: `DEP-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
        amount: finalAmount,
        blockchainTx: externalRef,
        type: "DEPOSIT",
        status: "SUCCESS",
        fromUserId: userId,
        toUserId: userId,
        toWalletId: userWallet.id,
        description: `Dépôt ${provider} (Automatique)`,
        metadata: {
          txHash,
          paymentId,
          method: provider,
          processedAt: new Date().toISOString()
        }
      }
    });

    // 6. Mise à jour du solde IMMÉDIATE pour tous les dépôts
    await prisma.wallet.update({
      where: { id: userWallet.id },
      data: { balance: { increment: finalAmount } }
    });

    // 7. Notification de confirmation avec metadonnees completes
    await prisma.notification.create({
      data: {
        userId,
        title: "Depot reussi !",
        message: `Votre compte a ete credite de ${finalAmount} ${currency}.`,
        type: "SUCCESS",
        metadata: JSON.stringify({
          amount: finalAmount,
          currency: currency,
          fee: 0,
          reference: deposit.reference,
          transactionId: deposit.id,
          method: provider || "Depot",
          status: "SUCCESS",
          network: provider === "PI" ? "Pi Network" : "Blockchain",
          blockchainTx: externalRef,
        }),
      }
    });

    // 8. Verifier et accorder le bonus de parrainage si eligible (KYC + premier depot)
    await grantReferrerBonusIfEligible(userId);

    return NextResponse.json({
      success: true,
      reference: deposit.reference,
      amount: deposit.amount,
      status: deposit.status
    });

  } catch (error: any) {
    console.error("DEPOSIT_ERROR:", error.message);
    return NextResponse.json({ error: "Erreur lors du traitement du dépôt" }, { status: 500 });
  }
}
